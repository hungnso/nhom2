import './bootstrap.js';
import './router.js'

// khong sua vao day
// import "./data/seed.js"